# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))
    """
    "*** YOUR CODE HERE IF YOU WANT TO PRACTICE ***"
    openlist = util.Stack()
    closedList = []
    actions = []

    openlist.push((problem.getStartState(), actions))
    while not openlist.isEmpty():
        currentstate, actions = openlist.list.pop()
        if problem.isGoalState(currentstate):
            return actions
        if currentstate not in closedList:
            closedList.append(currentstate)
            gamesuccessors = problem.getSuccessors(currentstate)
            for successors, action, stepcost in gamesuccessors:
                if successors not in closedList:
                    newactions = actions + [action]
                    openlist.push((successors, newactions))
    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE IF YOU WANT TO PRACTICE ***"
    openlist = util.Queue()
    closedList = []
    actions = []
    openlist.push((problem.getStartState(), actions))

    while not openlist.isEmpty():
        currentstate, actions = openlist.list.pop()
        if problem.isGoalState(currentstate):
            return actions
        if currentstate not in closedList:
            closedList.append(currentstate)
            gamesuccessors = problem.getSuccessors(currentstate)
            for successors, action, stepcost in gamesuccessors:
                if successors not in closedList:
                    newactions = actions + [action]
                    openlist.push((successors, newactions))
    util.raiseNotDefined()





def iterativeDeepeningSearch(problem):
    """Search the deepest node in an iterative manner."""
    "*** YOUR CODE HERE FOR TASK 1 ***"

    openList = util.Stack()

    limit_depth = 1

    while True:  # repeat search with the depth increases until we find the goal
        closedList=[]
        # push the starting point into stack
        openList.push((problem.getStartState(), [], 0))
        # pop out the point
        (currentstate, actions, stepCost) = openList.pop()
        # add the point to visited list
        closedList.append(currentstate)
        while not problem.isGoalState(currentstate):  # while we do not find the goal point
            successors = problem.getSuccessors(currentstate)  # get the point's succesors
            for successor,action,cost in successors:
                # add the points when it meets 1. not been visited 2. within the depth
                if not successor in closedList:
                    if (stepCost + cost <= limit_depth):
                        openList.push((successor, actions+[action], stepCost+cost))
                        closedList.append(successor)  # add this point to visited list

            if openList.isEmpty():  # if the no goal is found within the current depth, jump out and increase the depth
                break

            (currentstate, actions, stepCost) = openList.pop()

        if problem.isGoalState(currentstate):
            return actions

        limit_depth += 1  # increase the depth
    # openList=util.Stack()
    # limited_depth=1
    # visitedList=[]
    # actions=[]
    #
    #
    #
    # while True:
    #     openList.push((problem.getStartState(), actions, 0))
    #     currentstate,actions,cost=openList.pop()
    #     visitedList.append(currentstate)
    #     while not problem.isGoalState(currentstate):
    #         successors=problem.getSuccessors(currentstate)
    #         for successor,action,stepcost in successors:
    #             if successor not in visitedList:
    #                 if cost+stepcost<=limited_depth:
    #                     openList.push((successor,actions+[action],cost+stepcost))
    #                     visitedList.append (successor)
    #         if openList.isEmpty():
    #             break
    #         (currentstate,actions,cost)=openList.pop()
    #     if problem.isGoalState(currentstate):
    #         return actions
    #     limited_depth+=1
    #



# def dls(problem, depth):
#     # dlf -> busca em profundidade limitada
#    openlist=util.Queue()
#    closedlist=[]
#    actions=[]
#    openlist.push((problem.getStartState(),actions))
#    node = ((problem.getStartState(), actions))
#
#    def dls_rec(node, problem, depth):
#         currentstate, actions = openlist.list.pop()
#         if currentstate not in closedlist:
#             closedlist.append(currentstate)
#             if problem.isGoalState(currentstate):
#                 return actions
#             elif depth == 0:
#                 return 'exit'
#             else:
#                 exit = False
#                 for i in problem.getSuccessors(currentstate):
#                     successor, action_state, stepcost = i
#                     next_node = (successor, actions+ [action_state])
#                     openlist.push((successor,actions+[action_state]))
#                     result = dls_rec(next_node, problem, depth - 1)
#
#                     if result == 'exit':
#                         exit = True
#                     elif result is not None:
#                         return result
#                 return 'exit' if exit else None
#    return dls_rec(node, problem, depth)
#





def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE IF YOU WANT TO PRACTICE ***"
    openlist = util.PriorityQueue()
    closedList = []
    actions = []
    transitionlist = []
    openlist.push((problem.getStartState(), actions), priority=0)
    while not openlist.isEmpty():
        currentstate, actions = openlist.pop()
        if problem.isGoalState(currentstate):
            return actions
        if currentstate not in closedList:
            closedList.append(currentstate)
            gamesuccessors = problem.getSuccessors(currentstate)
            for successor, action, stepcost in gamesuccessors:
                transitionlist = actions + [action]
                actioncost = problem.getCostOfActions(transitionlist)
                if successor not in closedList:
                    openlist.update((successor, transitionlist), actioncost)
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE IF YOU WANT TO PRACTICE ***"


    openlist=util.PriorityQueue()
    closedlist=[]
    actions=[]
    openlist.push((problem.getStartState(),actions),0)
    while not openlist.isEmpty():
        currentstate,actions=openlist.pop()
        if problem .isGoalState(currentstate):
            return  actions
        if currentstate not in closedlist:
            closedlist.append(currentstate)
            gamesuccessors=problem.getSuccessors(currentstate)
            for successor,action,stepcost in gamesuccessors:
                updateactions=actions+[action]
                getcost=problem.getCostOfActions(updateactions)
                heuristicmethod=heuristic(successor,problem)
                if successor not in closedlist:
                    openlist.push((successor,updateactions),getcost+heuristicmethod)

    util.raiseNotDefined()




def waStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has has the weighted (x 2) lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE FOR TASK 2 ***"
    openlist=util.PriorityQueue()
    closedlist=[]
    actions=[]
    openlist.push((problem.getStartState(),actions),priority=0)


    while not openlist.isEmpty():
        currentstate,actions=openlist.pop()
        if problem .isGoalState(currentstate):
            return  actions
        if currentstate not in closedlist:
            closedlist.append(currentstate)
            gamesuccessors=problem.getSuccessors(currentstate)
            for i in gamesuccessors:
                successor,action,stepcost=i
                updateactions=actions+[action]
                getcost=problem.getCostOfActions(updateactions)
                heuristicmethod=2*heuristic(successor,problem)
                if successor not in closedlist:
                    openlist.push((successor,updateactions),getcost+heuristicmethod)

    util.raiseNotDefined()




# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
ids = iterativeDeepeningSearch
wastar = waStarSearch
